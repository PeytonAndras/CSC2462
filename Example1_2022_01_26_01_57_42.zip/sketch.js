function setup() {
  createCanvas(500 , 225);
}

function draw() {
  background(250, 400, 0);
  circle(125, 115, 200)
  square(275, 15, 200)
}