var brushColor;
function setup() {
  createCanvas(600, 600);
  strokeWeight(4);
  background(255)
  brushColor = color(50);


}

function draw() {
  if (mouseIsPressed) {
    if (mouseX <= 50) {
      if (mouseY <= 50) {
        brushColor = color(255, 0, 0);
      } else if (mouseY <= 100) {
        brushColor = color(0, 255, 0);
      } else if (mouseY <= 150) {
        brushColor = color(0, 0, 255);
      } else if (mouseY <= 200) {
        brushColor = color(249, 99, 0);
      } else if (mouseY <= 250) {
        brushColor = color(102, 178, 255);
      } else if (mouseY <= 300) {
        brushColor = color(242, 255, 0);
      } else if (mouseY <= 350) {
        brushColor = color(0, 137, 9);
      } else if(mouseY <= 400){
        brushColor = color(0, 0, 0);
      } else if(mouseY <= 450){
        brushColor = color(255, 255, 255);
      } else if(mouseY <= 500){
        brushColor = color(204, 0, 102);
      } else if(mouseY <= 550){
        brushColor = color(51, 25, 0);
      } else if(mouseY <= 600){
        brushColo = color(102, 0 , 204);
      }
    }
    stroke(brushColor)
    line(mouseX, mouseY, pmouseX, pmouseY);
  }

  
  noStroke(color(0));
  fill(255, 0, 0);
  rect(0, 0, 50, 50);
  fill(0, 255, 0);
  rect(0, 50, 50, 50);
  fill(0, 0, 255);
  rect(0, 100, 50, 50);
  fill(249, 99, 0);
  rect(0, 150, 50, 50)
  fill(102, 178, 255);
  rect(0, 200, 50, 50);
  fill(242, 255, 0);
  rect(0, 250, 50, 50);
  fill(0, 137, 9);
  rect(0, 300, 50, 50);
  fill(0, 0, 0);
  rect(0, 350, 50, 50);
  fill(255, 255, 255);
  rect(0, 400, 50, 50);
  fill(204, 0, 102);
  rect(0, 450, 50, 50);
  fill(51, 25, 0);
  rect(0, 500, 50, 50);
  fill(102, 0, 204);
  rect(0, 550, 50, 50);

  print(brushColor)

}