
let sound1 = new Tone.Player('media/sadTrombone.mp3');

const sounds = new Tone.Players({
  guitarBlam : 'media/guitarBlam.mp3',
  bringit : 'media/bringit.mp3',
  sadTrombone : 'media/sadTrombone.mp3',
  yesthatsit : 'media/yesthatsit.mp3'
})

let soundNames = ['guitarBlam', 'bringit', 'sadTrombone', 'yesthatsit']

const delay = new Tone.FeedbackDelay("8n", 0.5);

let buttons = [];
let button;
let button2;
let button3;
let button4;
let slider;

function setup() {
  createCanvas(400, 400);
  sound1.connect(delay);
  sounds.connect(delay);
  delay.toDestination();


  // button = createButton('Sad Trombone');
  // button.position(200,400);
  // button.mousePressed(   ()=>playSound('sadTrombone')  );

  // button2 = createButton('Guitar Blam');
  // button2.position(100,400);
  // button2.mousePressed(   ()=>playSound('guitarBlam')  );

  // button3 = createButton('"Bring It"');
  // button3.position(100,200);
  // button3.mousePressed(   ()=>playSound('bringit')  );
  
  slider = createSlider(0.,1.,0.5,0.05);
  slider.mouseReleased( ()=>{
    delay.delayTime.value = slider.value();
  })
  soundNames.forEach((name, index) =>{
    buttons[index] = createButton(name);
    buttons[index].position(index * 100, 100);
    buttons[index].mousePressed( () => playSound(name) );
  })
}

function draw() {
  background(220);
  text('Press these buttons', 20, 70)
}

// function keyPressed(){
//   console.log("key is:", key);
//   if(key === "1"){
//     sounds.player('bringit').start();
   // sound1.start;
  //}
  // sound1.playbackRate = (mouseY / 200) + 0.01;
  // sound1.start();
//}

function playSound(whichSound = 'guitarBlam'){

  sounds.player(whichSound).start();

}
