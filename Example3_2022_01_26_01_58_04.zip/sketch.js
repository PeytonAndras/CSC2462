function setup() {
  createCanvas(500, 280);
}

function draw() {
  background(2);
  fill(255,255,0)
  arc(120,130,140,140,0, PI+PI)
  fill(2)
  triangle(40, 190, 40, 20, 110, 135)
  fill(255,0,0)
  rect(300,60,140,140,70,70,5,5)
  fill(255,255,255)
  circle(340,125,45)
  circle(395,125,45)
  fill(0,0,255)
  circle(340,125,25)
  circle(395,125,25)


}