function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  fill(255,0, 0, 100)
  strokeWeight(0)
  circle(190, 125, 180, 125)
  fill(255, 255, 0, 125)
  circle(260, 250, 180, 125)
  fill(0, 0, 204, 100)
  circle(130, 250, 180, 125)
}